import { createContext, useContext, useState } from "react";

export const totalcount = createContext({
  number: 0,
  increase: () => {},
  decrease: () => {},
});

export function POSTcontextProvider({ children }) {
  const [number, setnumber] = useState(0);
  function increase() {
    setnumber((number) => number + 1);
  }
  function decrease() {
    setnumber((number) => number - 1);
  }
  return (
    <totalcount.Provider value={{ number, increase, decrease }}>
      {children}
    </totalcount.Provider>
  );
}

export function Usepostcontext() {
  let { number, increase, decrease } = useContext(totalcount);

  return { number, increase, decrease };
}
