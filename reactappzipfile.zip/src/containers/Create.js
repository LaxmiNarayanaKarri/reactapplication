import React, { useState } from "react";
import { addPost } from "../redux/post_slice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Usepostcontext } from "../context/Application";
import { Link, useParams } from "react-router-dom";

function Create() {
  const [title, settitle] = useState("");
  const [category, setcategory] = useState("");
  const [content, setcontent] = useState("");
  const posts = useSelector((state) => state.posts);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { increase } = Usepostcontext();
  const handleSubmit = (event) => {
    event.preventDefault();
    increase();
    if (posts.length != 0) {
      dispatch(
        addPost({
          id: posts[posts.length - 1].id + 1,
          title,
          category,
          content,
          like: "like",
        })
      );
    } else {
      dispatch(addPost({ id: 1, title, category, content, like: "like" }));
    }

    navigate("/");
  };
  return (
    <div className="container">
      <h3 className="text-center">CREATE POST</h3>
      <br />
      <Link to={"/"}>Back to Home</Link>
      <br />
      <div>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="name">TITLE:</label>
            <input
              type="text"
              className="form-control"
              name="title"
              required
              onChange={(e) => settitle(e.target.value)}
            ></input>
            <label htmlFor="name">CATEGORIES:</label>
            <input
              type="text"
              className="form-control"
              name="category"
              required
              onChange={(e) => setcategory(e.target.value)}
            ></input>
            <label htmlFor="name">CONTENT:</label>
            <textarea
              className="form-control"
              name="content"
              required
              onChange={(e) => setcontent(e.target.value)}
            ></textarea>
            <br />
            <button className="btn btn-info"> SUBMIT</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Create;
