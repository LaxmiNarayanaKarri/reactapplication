import React, { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { updatePost } from "../redux/post_slice";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

function EDIT() {
  const { id } = useParams();
  const posts = useSelector((state) => state.posts);
  const existingpost = posts.filter((f) => f.id == id);
  const { title, category, content } = existingpost[0];
  const [utitle, settitle] = useState(title);
  const [ucategory, setcategory] = useState(category);
  const [ucontent, setcontent] = useState(content);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const handleSubmit = (event) => {
    event.preventDefault();

    dispatch(
      updatePost({
        id: id,
        title: utitle,
        category: ucategory,
        content: ucontent,
      })
    );

    navigate("/");
  };
  return (
    <div className="container">
      <h3 className="text-center">EDIT POST</h3>
      <br />
      <div>
        <form onSubmit={handleSubmit}>
          <div>
            <label htmlFor="name">TITLE:</label>
            <input
              type="text"
              className="form-control"
              name="title"
              value={utitle}
              required
              onChange={(e) => settitle(e.target.value)}
            ></input>
            <label htmlFor="name">CATEGORIES:</label>
            <input
              type="text"
              className="form-control"
              name="category"
              value={ucategory}
              required
              onChange={(e) => setcategory(e.target.value)}
            ></input>
            <label htmlFor="name">CONTENT:</label>
            <textarea
              className="form-control"
              name="content"
              value={ucontent}
              required
              onChange={(e) => setcontent(e.target.value)}
            ></textarea>
            <br />
            <button className="btn btn-info"> SUBMIT</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default EDIT;
