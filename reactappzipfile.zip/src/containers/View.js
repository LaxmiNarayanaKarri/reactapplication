import React from "react";
import { Link, useParams } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { useState } from "react";
import { updateLike } from "../redux/post_slice";
import { deletePost } from "../redux/post_slice";
import { useNavigate } from "react-router-dom";
import "bootstrap-icons/font/bootstrap-icons.css";
import { Usepostcontext } from "../context/Application";

function View() {
  const { id } = useParams();
  const posts = useSelector((state) => state.posts);
  const existingpost = posts.filter((f) => f.id == id);
  const { title, category, content, like } = existingpost[0];
  const [like_status, setlike] = useState(like);
  const { decrease } = Usepostcontext();
  const [back_ground, setback] = useState("secondary");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const handleDelete = () => {
    console.log(id);
    decrease();
    dispatch(deletePost({ id }));
    navigate("/");
  };
  const changelink = () => {
    if (like_status == "like") {
      setlike("dislike");
      setback("primary");
    } else {
      setlike("like");
      setback("secondary");
    }
    dispatch(updateLike({ id, like: like_status }));
  };
  return (
    <div className="container">
      <h3 className="text-center">View POST</h3>
      <br />
      <div>
        <Link to={"/"}>Back to index</Link>
        <div className="d-flex justify-content-end">
          <button className={`btn btn-${back_ground}`} onClick={changelink}>
            <i class="bi bi-hand-thumbs-up"> Like</i>
          </button>
          <Link to={`/edit/${id}`} className="btn btn-warning ms-2">
            Edit
          </Link>
          <button onClick={handleDelete} className="btn btn-danger ms-2">
            Delete
          </button>
        </div>
      </div>
      <div className="container">
        <p>
          <h4>TITLE : {title}</h4>
          <br />
          <h4>CATEGORY : {category} </h4>

          <br />
          <h4>CONTENT : {content}</h4>
        </p>
      </div>
    </div>
  );
}

export default View;
