import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { Usepostcontext } from "../context/Application";

function Home() {
  const posts = useSelector((state) => state.posts);
  const { number } = Usepostcontext();
  return (
    <div className="container">
      <h3 className="text-center">BLOG POSTS</h3>
      <br />
      <h4>Total Number of POSTS: {number}</h4>
      <Link to="/create" className="btn btn-success my3">
        NEW POST
      </Link>
      <br />
      <table className="table">
        <thead>
          <tr>
            <th>Sr NO:</th>
            <th>Title</th>
            <th>View</th>
          </tr>
        </thead>
        <tbody>
          {posts.map((post, index) => (
            <tr>
              <td>{post.id}</td>
              <td>{post.title}</td>
              <td>
                <Link to={`/view/${post.id}`} className="btn btn-primary">
                  VIEW
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Home;
