import { createSlice } from "@reduxjs/toolkit";

const postSlice = createSlice({
  name: "post",
  initialState: [],
  reducers: {
    addPost: (state, action) => {
      state.push(action.payload);
    },
    updateLike: (state, action) => {
      const { id, like } = action.payload;
      const current_post = state.find((user) => user.id == id);
      if (current_post) {
        if (like == "like") {
          current_post.like = "dislike";
        } else {
          current_post.like = "like";
        }
      }
    },
    updatePost: (state, action) => {
      const { id, titel, category, content } = action.payload;
      const current_post = state.find((user) => user.id == id);
      if (current_post) {
        current_post.titel = titel;
        current_post.content = content;
        current_post.category = category;
      }
    },
    deletePost: (state, action) => {
      const { id } = action.payload;
      console.log(id, "when string");
      const nid = parseInt(id);
      console.log(nid, "when integer");
      const current_post = state.find((user) => user.id == id);
      if (current_post) {
        console.log(current_post, id);
        return state.filter((f) => f.id !== nid);
      }
    },
  },
});

export const { addPost, updateLike, updatePost, deletePost } =
  postSlice.actions;
export default postSlice.reducer;
