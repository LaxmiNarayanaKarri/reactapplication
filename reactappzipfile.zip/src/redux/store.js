import { configureStore } from "@reduxjs/toolkit";
import post_slice from "./post_slice";

const store = configureStore({
  reducer: {
    posts: post_slice,
  },
});
export default store;
