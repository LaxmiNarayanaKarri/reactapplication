import "bootstrap/dist/css/bootstrap.min.css";
import Home from "./containers/Home";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Create from "./containers/Create";
import View from "./containers/View";
import EDIT from "./containers/Edit";
import { POSTcontextProvider } from "./context/Application";

function App() {
  return (
    <POSTcontextProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}></Route>
          <Route path="/create" element={<Create />}></Route>
          <Route path="/view/:id" element={<View />}></Route>
          <Route path="/edit/:id" element={<EDIT />}></Route>
        </Routes>
      </BrowserRouter>
    </POSTcontextProvider>
  );
}

export default App;
